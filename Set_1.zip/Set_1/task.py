#1
# print("hellow world")

#2
# name="ajay"
# print(name)

# # # 4
# name="ajay"
# age=22
# print(name)
# print(age)

# # 5
# name="ajay"
# age=22
# bollen=True
# print(name)
# print(age)
# print(bollen)


# # 6
# name="ajay"
# age=22
# print(name,age)

# # 7
# name="ajay"
# age=22
# print("my name is",name,"i am",age,"years old.")


# # # 8
# name = "ajay"  
# age = 25
# print("My name is",name, "I am",age,"years old.")



# 7
# # Write a program that calculates and prints the result of all mathematical operations. Declare variables for the operands (e.g., addition, subtraction, multiplication, division).

# a=20
# b=50
# c=a+b,a-b,a*b,a%b
# print(c)

# 8
# # Declare an array of strings and print each element of the array to the console.
# fruits = ["Apple", "Banana", "Cherry"]
# for fruit in fruits:
#     print(fruit)

# 9
# # Write a program to print a simple pattern using asterisks or any other character. For example: 
# * 
# ** 
# *** 
# ****

# a = 4
# for i in range(1, a + 1):
#     print('*' * i)


# # 10
# # Declare a variable name and assign it a string value. Declare a variable age and assign it a numerical value. Declare a variable isStudent and assign it a boolean value.
# # Print the value of each variable to the console.
# # Change the value of the name variable to another string. Increment the value of the age variable by 1. Toggle the value of the isStudent variable (from true to false or vice versa).

# name="ajay"
# age=22
# isstudent=True
# print("name",name)
# print("age",age)
# print("isstudent",isstudent)

# 11
# # Write a program to store the below details with separate variables (name, age, dob, height, weight, degree, gender, is_alive). Set the values with appropriate types based on the value. Say age should be an integer, etc.,

# name="ajay"
# age=22
# dob=30_9_2002
# height=75.1
# weight=55
# degre="b.sc statistics"
# gender="male"
# is_alive=True
# print("personal details")
# print("name:",name)
# print("age:",age)
# print("dob:",dob)
# print("height:",height)
# print("weight:",weight)
# print("degre:",degre)
# print("genter:",gender)
# print("is alive",is_alive)


